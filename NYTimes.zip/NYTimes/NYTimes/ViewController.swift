//
//  ViewController.swift
//  NYTimes
//
//  Created by HYLPMB00015 on 09/08/18.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{

    var results = [resultArray]()
    
    @IBOutlet weak var NYTblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.barTintColor = UIColor(red: 63/255, green: 222/255, blue: 177/255, alpha: 1.0)
       
        
        self.NYTblView.delegate = self
        self.NYTblView.dataSource = self
        
        self.NYTblView.estimatedRowHeight = 115
        
        self.NYTblView.rowHeight = UITableViewAutomaticDimension
        
      
        self.NYTblView.setNeedsLayout()
        self.NYTblView.layoutIfNeeded()
        self.getRequst()
    }
    func getRequst() {
        let urlString = "https://api.nytimes.com/svc/mostpopular/v2/mostviewed/all-sections/30.json?api-key=efc3dcfe04034f0ba50466ab70e59fef"
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with: url!) { data, response, err in
            
            guard let Response = data else{
                return
            }
            
            do{
                
                let jsonResponse = try JSONDecoder().decode(getResponse.self, from: Response)
                self.results = jsonResponse.results
                
                
                DispatchQueue.main.async {
                    self.NYTblView.reloadData()
                    
                }
            }
                
            catch let errorData
                
            {
                print(errorData)
                
                
            }
            
            
            }.resume()
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return results.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = NYTblView.dequeueReusableCell(withIdentifier: "newCell", for: indexPath) as! newCell
        cell.lbl_title.text = self.results[indexPath.row].title
        cell.lbl_abstract.text = self.results[indexPath.row].abstract
        cell.lbl_byline.text = self.results[indexPath.row].byline
        cell.lbl_date.text = self.results[indexPath.row].published_date
        
        return cell
    }
  

}

