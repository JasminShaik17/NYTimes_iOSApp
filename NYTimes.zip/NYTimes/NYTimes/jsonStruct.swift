//
//  jsonStruct.swift
//  NYTimes
//
//  Created by HYLPMB00015 on 09/08/18.
//  Copyright © 2018 Naveen. All rights reserved.
//

import Foundation


struct getResponse:Decodable {
    let results:[resultArray]
}

struct resultArray:Decodable {
    let title : String
    let abstract : String
    let byline : String
    let published_date : String
}
