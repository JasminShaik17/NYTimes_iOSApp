//
//  newCell.swift
//  NYTimes
//
//  Created by HYLPMB00015 on 09/08/18.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

class newCell: UITableViewCell {

    @IBOutlet weak var my_imgview: UIImageView!
    @IBOutlet weak var lbl_title: UILabel!
    
    @IBOutlet weak var lbl_abstract: UILabel!
    
    @IBOutlet weak var lbl_byline: UILabel!
    
    @IBOutlet weak var lbl_date: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
